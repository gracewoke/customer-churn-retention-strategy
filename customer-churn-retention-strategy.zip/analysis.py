"""Customer churn & retention strategy analysis — Maven Communications (Q2 2022 dataset).

Steps: clean -> descriptive churn analysis -> churn-risk model -> revenue at risk -> retention playbook.
Outputs results.json (every figure used on the portfolio page) and scored_customers.csv.
"""
import json
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.metrics import roc_auc_score, precision_score, recall_score
from sklearn.inspection import permutation_importance

RNG = 42
df = pd.read_csv("data/telecom_customer_churn.csv")
out = {}

# ---------- 1. Clean ----------
# Service add-ons are blank when the customer has no internet/phone service -> treat as "No service"
svc_cols = ["Multiple Lines", "Internet Type", "Online Security", "Online Backup", "Device Protection Plan",
            "Premium Tech Support", "Streaming TV", "Streaming Movies", "Streaming Music", "Unlimited Data"]
for c in svc_cols:
    df[c] = df[c].fillna("No service")
df["Offer"] = df["Offer"].fillna("None")
for c in ["Avg Monthly Long Distance Charges", "Avg Monthly GB Download"]:
    df[c] = df[c].fillna(0)
df["churned"] = (df["Customer Status"] == "Churned").astype(int)
df["tenure_band"] = pd.cut(df["Tenure in Months"], [0, 6, 12, 24, 48, 72],
                           labels=["0-6 mo", "7-12 mo", "13-24 mo", "25-48 mo", "49-72 mo"])
df["age_band"] = pd.cut(df["Age"], [18, 30, 45, 60, 80], right=False, labels=["18-29", "30-44", "45-59", "60+"])

# ---------- 2. Headline numbers ----------
n = len(df)
churned = df[df.churned == 1]
out["customers"] = n
out["status_counts"] = df["Customer Status"].value_counts().to_dict()
out["churn_rate_all"] = round(churned.shape[0] / n * 100, 1)
existing = df[df["Customer Status"] != "Joined"]
out["churn_rate_existing"] = round(existing.churned.mean() * 100, 1)
out["revenue_total"] = round(df["Total Revenue"].sum())
out["revenue_lost_lifetime"] = round(churned["Total Revenue"].sum())
out["revenue_lost_share"] = round(churned["Total Revenue"].sum() / df["Total Revenue"].sum() * 100, 1)
out["mrr_lost"] = round(churned["Monthly Charge"].sum())
out["arr_lost"] = round(churned["Monthly Charge"].sum() * 12)
out["avg_monthly_churned"] = round(churned["Monthly Charge"].mean(), 2)
out["avg_monthly_stayed"] = round(df[df["Customer Status"] == "Stayed"]["Monthly Charge"].mean(), 2)


def rate_by(col, base=existing):
    g = base.groupby(col, observed=True).agg(customers=("churned", "size"), churn_rate=("churned", "mean"))
    g["churn_rate"] = (g.churn_rate * 100).round(1)
    return [{"group": str(k), "customers": int(r.customers), "churn_rate": float(r.churn_rate)} for k, r in g.iterrows()]


# churn rates computed on existing customers (Stayed + Churned): new joiners had no chance to churn yet
for col, key in [("Contract", "by_contract"), ("tenure_band", "by_tenure"), ("Internet Type", "by_internet"),
                 ("Offer", "by_offer"), ("Premium Tech Support", "by_tech_support"),
                 ("Online Security", "by_security"), ("Payment Method", "by_payment"), ("age_band", "by_age")]:
    out[key] = rate_by(col)
ref = existing.assign(has_referral=np.where(existing["Number of Referrals"] > 0, "1+ referrals", "No referrals"))
out["by_referrals"] = rate_by("has_referral", ref)

cat = churned["Churn Category"].value_counts()
out["churn_categories"] = [{"category": k, "customers": int(v), "share": round(v / len(churned) * 100, 1)} for k, v in cat.items()]
rs = churned["Churn Reason"].value_counts().head(8)
out["top_reasons"] = [{"reason": k, "customers": int(v), "share": round(v / len(churned) * 100, 1)} for k, v in rs.items()]
cat_rev = churned.groupby("Churn Category")["Monthly Charge"].sum().sort_values(ascending=False) * 12
out["arr_lost_by_category"] = {k: round(v) for k, v in cat_rev.items()}

city = existing.groupby("City").agg(customers=("churned", "size"), churn_rate=("churned", "mean"))
out["top_city_by_volume"] = city.assign(churned=lambda d: d.customers * d.churn_rate).sort_values("churned", ascending=False).head(3).round(3).reset_index().to_dict("records")

# ---------- 3. Churn-risk model (trained on Stayed vs Churned) ----------
num = ["Age", "Number of Dependents", "Number of Referrals", "Tenure in Months", "Avg Monthly Long Distance Charges",
       "Avg Monthly GB Download", "Monthly Charge"]
catf = ["Gender", "Married", "Offer", "Phone Service", "Multiple Lines", "Internet Service", "Internet Type",
        "Online Security", "Online Backup", "Device Protection Plan", "Premium Tech Support", "Streaming TV",
        "Streaming Movies", "Streaming Music", "Unlimited Data", "Contract", "Paperless Billing", "Payment Method"]
# Excluded on purpose: Total Charges/Revenue/Refunds (accumulate with tenure = leakage-prone), churn category/reason (only known after churn), location ids.
X, y = existing[num + catf], existing["churned"]
Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=0.25, stratify=y, random_state=RNG)
pre = ColumnTransformer([("num", StandardScaler(), num), ("cat", OneHotEncoder(handle_unknown="ignore"), catf)])
logit = Pipeline([("pre", pre), ("m", LogisticRegression(max_iter=2000, C=1.0))]).fit(Xtr, ytr)
pre2 = ColumnTransformer([("num", "passthrough", num), ("cat", OneHotEncoder(handle_unknown="ignore", sparse_output=False), catf)])
gbm = Pipeline([("pre", pre2), ("m", HistGradientBoostingClassifier(max_iter=300, learning_rate=0.05, max_depth=4, random_state=RNG))]).fit(Xtr, ytr)

models = {}
for name, m in [("Logistic regression", logit), ("Gradient boosting", gbm)]:
    p = m.predict_proba(Xte)[:, 1]
    pred = (p >= 0.5).astype(int)
    models[name] = {"auc": round(roc_auc_score(yte, p), 3), "precision": round(precision_score(yte, pred), 3),
                    "recall": round(recall_score(yte, pred), 3)}
out["models"] = models
best_name = max(models, key=lambda k: models[k]["auc"])
best = gbm if best_name == "Gradient boosting" else logit
out["best_model"] = best_name

# Top-decile lift on the test set: how concentrated churners are among the highest-risk 10%
p_te = best.predict_proba(Xte)[:, 1]
top = pd.Series(p_te).rank(ascending=False, method="first") <= int(len(p_te) * 0.10)
out["top_decile_churn_rate"] = round(yte.values[top.values].mean() * 100, 1)
out["test_base_rate"] = round(yte.mean() * 100, 1)
out["top_decile_lift"] = round(yte.values[top.values].mean() / yte.mean(), 2)
out["test_size"] = int(len(yte))

pi = permutation_importance(best, Xte, yte, scoring="roc_auc", n_repeats=10, random_state=RNG)
imp = pd.Series(pi.importances_mean, index=num + catf).sort_values(ascending=False).head(8)
out["drivers"] = [{"feature": k, "auc_drop": round(v, 3)} for k, v in imp.items()]

# ---------- 4. Score current customers & revenue at risk ----------
# Out-of-fold scores for existing customers (so no customer is scored by a model that saw them),
# and a model refit on all existing customers to score this quarter's new joiners.
from sklearn.base import clone
from sklearn.model_selection import cross_val_predict, StratifiedKFold
oof = cross_val_predict(clone(best), X, y, cv=StratifiedKFold(5, shuffle=True, random_state=RNG), method="predict_proba")[:, 1]
existing_risk = pd.Series(oof, index=existing.index)
full = clone(best).fit(X, y)
cur = df[df["Customer Status"] != "Churned"].copy()
cur["risk"] = existing_risk.reindex(cur.index)
joined_idx = cur.index[cur["Customer Status"] == "Joined"]
cur.loc[joined_idx, "risk"] = full.predict_proba(cur.loc[joined_idx, num + catf])[:, 1]
out["joined_avg_risk"] = round(cur.loc[joined_idx, "risk"].mean() * 100, 1)
cur["annual_value"] = cur["Monthly Charge"] * 12
cur["expected_arr_at_risk"] = cur["risk"] * cur["annual_value"]
cur["risk_tier"] = pd.cut(cur["risk"], [-0.01, 0.2, 0.5, 1.0], labels=["Low", "Medium", "High"])
med_value = cur["Monthly Charge"].median()
cur["value_tier"] = np.where(cur["Monthly Charge"] >= med_value, "High value", "Lower value")
out["current_customers"] = int(len(cur))
out["median_monthly_charge"] = round(med_value, 2)
out["expected_arr_at_risk_total"] = round(cur["expected_arr_at_risk"].sum())
tiers = cur.groupby("risk_tier", observed=True).agg(customers=("risk", "size"), avg_risk=("risk", "mean"),
                                                     arr=("annual_value", "sum"), arr_at_risk=("expected_arr_at_risk", "sum"))
out["risk_tiers"] = [{"tier": str(k), "customers": int(r.customers), "avg_risk": round(r.avg_risk * 100, 1),
                      "arr": round(r.arr), "arr_at_risk": round(r.arr_at_risk)} for k, r in tiers.iterrows()]
hi = cur[cur.risk_tier == "High"]
out["high_risk_month_to_month_share"] = round((hi["Contract"] == "Month-to-Month").mean() * 100, 1)
out["high_risk_new_share"] = round((hi["Tenure in Months"] <= 12).mean() * 100, 1)
out["high_risk_share_of_at_risk_arr"] = round(hi["expected_arr_at_risk"].sum() / cur["expected_arr_at_risk"].sum() * 100, 1)

# ---------- 5. Retention playbook (segment = risk tier x value tier) ----------
# Stated assumptions (illustrative, to be validated with a pilot):
A = {"save_rate": {"High": 0.30, "Medium": 0.20},            # share of would-be churners an intervention keeps
     "cost_per_customer": {("High", "High value"): 120, ("High", "Lower value"): 60,
                           ("Medium", "High value"): 40, ("Medium", "Lower value"): 15}}
segs = []
plays = {("High", "High value"): "Protect: proactive call + contract upgrade offer (12-month price lock)",
         ("High", "Lower value"): "Stabilize: tech-support bundle trial + plan right-sizing",
         ("Medium", "High value"): "Nurture: loyalty perk + referral incentive",
         ("Medium", "Lower value"): "Automate: digital check-ins and self-serve offers",
         ("Low", "High value"): "Grow: upsell add-ons, no retention spend",
         ("Low", "Lower value"): "Maintain: business as usual"}
for (rt, vt), g in cur.groupby(["risk_tier", "value_tier"], observed=True):
    rt = str(rt)
    seg = {"risk": rt, "value": vt, "customers": int(len(g)), "avg_risk": round(g.risk.mean() * 100, 1),
           "arr_at_risk": round(g.expected_arr_at_risk.sum()), "play": plays[(rt, vt)]}
    if rt in A["save_rate"]:
        saved = g.expected_arr_at_risk.sum() * A["save_rate"][rt]
        cost = len(g) * A["cost_per_customer"][(rt, vt)]
        seg.update({"revenue_saved": round(saved), "cost": round(cost), "roi": round((saved - cost) / cost, 2)})
    segs.append(seg)
order = {"High": 0, "Medium": 1, "Low": 2}
segs.sort(key=lambda s: (order[s["risk"]], s["value"] != "High value"))
out["segments"] = segs
funded = [s for s in segs if "cost" in s]
out["program_cost"] = sum(s["cost"] for s in funded)
out["program_revenue_saved"] = sum(s["revenue_saved"] for s in funded)
out["program_net"] = out["program_revenue_saved"] - out["program_cost"]
out["program_roi"] = round(out["program_net"] / out["program_cost"], 2)
out["assumptions"] = {"save_rate": A["save_rate"], "cost_per_customer": {f"{k[0]} / {k[1]}": v for k, v in A["cost_per_customer"].items()}}

json.dump(out, open("results.json", "w"), indent=2, default=str)
cur[["Customer ID", "Contract", "Tenure in Months", "Monthly Charge", "risk", "risk_tier", "value_tier", "expected_arr_at_risk"]] \
    .sort_values("expected_arr_at_risk", ascending=False).round(3).to_csv("scored_customers.csv", index=False)
print(json.dumps(out, indent=1, default=str))
