# Customer Churn & Retention Strategy: Maven Communications

Who leaves a California telecom provider, why, who is likely to leave next, and where a retention budget earns the best return.

## Key results
- **26.5%** of 7,043 customers churned in the quarter, taking **$1.65M** of annual recurring revenue.
- Month-to-month customers churn at **51.7%** vs **2.6%** on two-year contracts; **77.2%** of customers in their first six months leave.
- Competitors explain **45%** of churn (better devices, better offers). Attitude of support staff is the top reason Maven controls (11.8%).
- Gradient boosting churn-risk model: **ROC-AUC 0.928** on a held-out test set; the riskiest 10% churned at 98.2% (3.5x lift).
- Tiered retention playbook: **$87K** cost, **$164K** revenue saved in year one (about $1.88 back per $1), under stated assumptions.

## Files
| File | What it is |
| --- | --- |
| `analysis.py` | Full pipeline: cleaning, churn analysis, models, scoring, playbook |
| `results.json` | Every figure used in the case study |
| `scored_customers.csv` | Churn-risk score, tier and revenue at risk for each current customer |
| `data/` | Maven Analytics Telecom Customer Churn dataset (public domain) |

## Method
1. Clean: blank service add-ons mean "no service"; tenure and age bands.
2. Churn rates on existing customers (new joiners excluded, since they could not have churned yet).
3. Logistic regression vs. histogram gradient boosting, 75/25 stratified split; permutation importance for drivers.
4. Current customers scored out-of-fold (5-fold), new joiners scored by a model refit on all existing customers.
5. Segments = risk tier (low < 20%, medium 20–50%, high > 50%) x value tier (monthly charge vs. $63.20 median).
6. Playbook costs and save rates are explicit assumptions (see `analysis.py`), to be validated with a pilot.

## Run it
```bash
pip install pandas scikit-learn
python analysis.py
```

## Limits
Fictional dataset, one quarter, one region, no service-call logs: results are associations, not proven causes.
